package com.service.contacto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContactoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContactoApplication.class, args);
	}

}
